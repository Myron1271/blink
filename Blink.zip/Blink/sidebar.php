<?php
/**
 * Default sidebar
 *
 * Please see /external/bootstrap-utilities.php for info on BsWp::get_template_parts()
 *
 * @package 	WordPress
 * @subpackage 	Bootstrap 5.2.0
 * @autor 		Babobski
 */
?>