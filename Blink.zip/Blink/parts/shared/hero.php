<div class="p-5" style="background: darkslategray">
    <div class="container text-light">
        <div class="row">
            <div class="col-6">
                <h1>Hallo mooie Text</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto assumenda dolorum fugit id
                    impedit incidunt maiores officiis, omnis perspiciatis quam quibusdam quo ratione reiciendis
                    repellat repellendus unde veniam voluptas voluptatem?</p>
            </div>
            <div class="col-6 d-flex justify-content-center">
                <img src="https://picsum.photos/200" alt="randFoto">
            </div>
        </div>
    </div>
</div>